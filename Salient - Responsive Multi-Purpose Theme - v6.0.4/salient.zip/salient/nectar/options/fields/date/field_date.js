/*global jQuery, document*/
jQuery(document).ready(function () {
    /*
     *
     * Redux_Options_date function
     * Adds datepicker js
     *
     */
    jQuery('.redux-opts-datepicker').datepicker();
});
